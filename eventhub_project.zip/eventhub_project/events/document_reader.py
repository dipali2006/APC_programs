
import os
import re
from datetime import datetime

from PIL import Image, ImageEnhance, ImageFilter
import pytesseract
from pypdf import PdfReader


# --------------------------------------------------
# TESSERACT CONFIGURATION
# --------------------------------------------------

pytesseract.pytesseract.tesseract_cmd = (
    r"C:\Program Files\Tesseract-OCR\tesseract.exe"
)


# --------------------------------------------------
# EXTRACT TEXT FROM IMAGE
# --------------------------------------------------

def extract_image_text(image):

    image = image.convert("RGB")

    # Improve image size for OCR
    image = image.resize(
        (image.width * 2, image.height * 2)
    )

    # Convert to grayscale
    image = image.convert("L")

    # Improve contrast
    image = ImageEnhance.Contrast(image).enhance(2)

    # Sharpen image
    image = image.filter(
        ImageFilter.SHARPEN
    )

    text = pytesseract.image_to_string(
        image,
        config="--psm 6",
    )

    return text.strip()


# --------------------------------------------------
# EXTRACT TEXT FROM IMAGE OR PDF
# --------------------------------------------------

def extract_text(file_path):

    extension = os.path.splitext(
        file_path
    )[1].lower()

    if extension == ".pdf":

        extracted_text = []

        reader = PdfReader(file_path)

        for page_number, page in enumerate(reader.pages):

            page_text = page.extract_text() or ""

            if page_text.strip():

                extracted_text.append(page_text)

            else:

                # OCR for scanned/image-based PDF pages
                try:

                    import fitz

                    document = fitz.open(file_path)

                    pdf_page = document[page_number]

                    pix = pdf_page.get_pixmap(
                        matrix=fitz.Matrix(2, 2)
                    )

                    image = Image.frombytes(
                        "RGB",
                        [pix.width, pix.height],
                        pix.samples,
                    )

                    extracted_text.append(
                        extract_image_text(image)
                    )

                    document.close()

                except Exception as error:

                    print(
                        "PDF OCR error:",
                        error,
                    )

        return "\n".join(
            extracted_text
        ).strip()

    elif extension in [
        ".jpg",
        ".jpeg",
        ".png",
        ".bmp",
    ]:

        image = Image.open(file_path)

        return extract_image_text(image)

    else:

        raise ValueError(
            "Unsupported file format. "
            "Upload JPG, JPEG, PNG, BMP, or PDF."
        )


# --------------------------------------------------
# NORMALIZE TEXT
# --------------------------------------------------

def normalize_text(text):

    if not text:
        return ""

    text = text.replace(
        "\r",
        "\n",
    )

    text = re.sub(
        r"[ \t]+",
        " ",
        text,
    )

    return text.strip()


# --------------------------------------------------
# FIND EVENT DATE
# --------------------------------------------------

def find_date(text):

    if not text:
        return None

    text = normalize_text(text)

    # DD/MM/YYYY, DD-MM-YYYY, DD.MM.YYYY
    numeric_pattern = (
        r"\b(\d{1,2})[./-](\d{1,2})[./-](\d{4})\b"
    )

    match = re.search(
        numeric_pattern,
        text,
    )

    if match:

        day = int(match.group(1))
        month = int(match.group(2))
        year = int(match.group(3))

        try:

            return datetime(
                year,
                month,
                day,
            ).date()

        except ValueError:

            pass

    # Dates with month names
    date_patterns = [
        r"\b\d{1,2}\s+[A-Za-z]+\s+\d{4}\b",
        r"\b[A-Za-z]+\s+\d{1,2},?\s+\d{4}\b",
    ]

    date_formats = [
        "%d %B %Y",
        "%d %b %Y",
        "%B %d %Y",
        "%B %d, %Y",
        "%b %d %Y",
        "%b %d, %Y",
    ]

    for pattern in date_patterns:

        matches = re.findall(
            pattern,
            text,
            re.IGNORECASE,
        )

        for date_string in matches:

            date_string = re.sub(
                r"\s+",
                " ",
                date_string.strip(),
            )

            for date_format in date_formats:

                try:

                    return datetime.strptime(
                        date_string,
                        date_format,
                    ).date()

                except ValueError:

                    continue

    return None


# --------------------------------------------------
# NORMALIZE TIME TEXT
# --------------------------------------------------

def normalize_time_text(text):

    if not text:
        return ""

    text = text.upper()

    # Convert 10.30 AM to 10:30 AM
    text = re.sub(
        r"(\d{1,2})[.,](\d{2})\s*([AP]\s*\.?\s*M\.?)",
        r"\1:\2 \3",
        text,
    )

    # Normalize AM
    text = re.sub(
        r"A\s*\.?\s*M\.?",
        "AM",
        text,
    )

    # Normalize PM
    text = re.sub(
        r"P\s*\.?\s*M\.?",
        "PM",
        text,
    )

    return text


# --------------------------------------------------
# FIND EVENT TIME
# --------------------------------------------------

def find_time(text):

    if not text:
        return None

    text = normalize_time_text(text)

    # Ignore next-day wording
    text = re.sub(
        r"\bNEXT\s+DAY\b",
        "",
        text,
        flags=re.IGNORECASE,
    )

    text = re.sub(
        r"\bTHE\s+FOLLOWING\s+DAY\b",
        "",
        text,
        flags=re.IGNORECASE,
    )

    # Find 12-hour time
    time_pattern = (
        r"\b\d{1,2}"
        r"(?:\s*:\s*\d{2})?"
        r"\s*(?:AM|PM)\b"
    )

    matches = re.findall(
        time_pattern,
        text,
        flags=re.IGNORECASE,
    )

    if matches:

        # First time is treated as the start time
        first_time = re.sub(
            r"\s+",
            " ",
            matches[0].strip(),
        )

        formats = [
            "%I:%M %p",
            "%I %p",
        ]

        for time_format in formats:

            try:

                parsed_time = datetime.strptime(
                    first_time,
                    time_format,
                ).time()

                return parsed_time.strftime(
                    "%H:%M"
                )

            except ValueError:

                continue

    # Handle 24-hour time
    twenty_four_hour_pattern = (
        r"\b(?:[01]?\d|2[0-3]):[0-5]\d\b"
    )

    matches = re.findall(
        twenty_four_hour_pattern,
        text,
    )

    if matches:

        try:

            parsed_time = datetime.strptime(
                matches[0],
                "%H:%M",
            ).time()

            return parsed_time.strftime(
                "%H:%M"
            )

        except ValueError:

            pass

    return None


# --------------------------------------------------
# FIND EVENT TITLE
# --------------------------------------------------

def find_event_title(text):

    if not text:
        return None

    # Return exactly "Seminar" when the poster
    # contains the word Seminar.
    if re.search(
        r"\bseminar\b",
        text,
        re.IGNORECASE,
    ):

        return "Seminar"

    # Other event titles
    event_keywords = [
        "workshop",
        "conference",
        "birthday",
        "wedding",
        "engagement",
        "annual day",
        "farewell",
        "reunion",
        "graduation",
        "celebration",
    ]

    for event_name in event_keywords:

        if re.search(
            rf"\b{re.escape(event_name)}\b",
            text,
            re.IGNORECASE,
        ):

            return event_name.title()

    return None


# --------------------------------------------------
# FIND EVENT VENUE
# --------------------------------------------------

def find_venue(text):

    if not text:
        return None

    lines = [
        line.strip()
        for line in text.splitlines()
        if line.strip()
    ]

    venue_labels = [
        "venue",
        "location",
        "address",
        "place",
        "held at",
        "organized at",
        "organised at",
    ]

    # Find venue using labels
    for index, line in enumerate(lines):

        for label in venue_labels:

            pattern = (
                rf"\b{re.escape(label)}\b"
                rf"\s*[:\-]?\s*(.*)"
            )

            match = re.search(
                pattern,
                line,
                flags=re.IGNORECASE,
            )

            if match:

                venue = match.group(1).strip()

                if venue:

                    venue = clean_venue(
                        venue
                    )

                    if venue:

                        return venue

                # Venue may be on the next line
                if index + 1 < len(lines):

                    venue = clean_venue(
                        lines[index + 1]
                    )

                    if venue:

                        return venue

    # Fallback for common venue names
    venue_patterns = [
        r"\b[A-Za-z ]*Seminar Hall\b",
        r"\b[A-Za-z ]*Auditorium\b",
        r"\b[A-Za-z ]*Conference Hall\b",
        r"\b[A-Za-z ]*College Hall\b",
    ]

    for line in lines:

        for pattern in venue_patterns:

            match = re.search(
                pattern,
                line,
                flags=re.IGNORECASE,
            )

            if match:

                return clean_venue(
                    match.group(0)
                )

    return None


# --------------------------------------------------
# CLEAN VENUE
# --------------------------------------------------

def clean_venue(venue):

    if not venue:
        return None

    venue = venue.strip()

    # Remove dates
    venue = re.sub(
        r"\b\d{1,2}\s+[A-Za-z]+\s+\d{4}\b",
        "",
        venue,
        flags=re.IGNORECASE,
    )

    venue = re.sub(
        r"\b[A-Za-z]+\s+\d{1,2},?\s+\d{4}\b",
        "",
        venue,
        flags=re.IGNORECASE,
    )

    venue = re.sub(
        r"\b\d{1,2}[./-]\d{1,2}[./-]\d{4}\b",
        "",
        venue,
    )

    # Remove time ranges
    venue = re.sub(
        r"\b\d{1,2}(?::|\.)\d{2}\s*(?:AM|PM)"
        r"\s*(?:TO|-|–|—)\s*"
        r"\d{1,2}(?::|\.)\d{2}\s*(?:AM|PM)\b",
        "",
        venue,
        flags=re.IGNORECASE,
    )

    # Remove individual times
    venue = re.sub(
        r"\b\d{1,2}(?::|\.)\d{2}\s*(?:AM|PM)\b",
        "",
        venue,
        flags=re.IGNORECASE,
    )

    # Remove extra symbols
    venue = re.sub(
        r"^[\s:=,\-–—]+",
        "",
        venue,
    )

    venue = re.sub(
        r"[\s:=,\-–—]+$",
        "",
        venue,
    )

    venue = re.sub(
        r"\s+",
        " ",
        venue,
    ).strip()

    if len(venue) < 3:
        return None

    return venue[:250]


# --------------------------------------------------
# FIND EVENT DESCRIPTION
# --------------------------------------------------

def find_description(text):

    if not text:
        return None

    lines = [
        line.strip()
        for line in text.splitlines()
        if line.strip()
    ]

    description_lines = []

    ignored_labels = [
        "date:",
        "time:",
        "venue:",
        "location:",
        "address:",
        "contact:",
        "phone:",
        "email:",
    ]

    for line in lines:

        lower_line = line.lower()

        if any(
            label in lower_line
            for label in ignored_labels
        ):

            continue

        if find_date(line):
            continue

        if find_time(line):
            continue

        if len(line) > 25:

            description_lines.append(line)

    if description_lines:

        return " ".join(
            description_lines
        )[:1000]

    return None


# --------------------------------------------------
# FIND CHECKLIST ITEMS
# --------------------------------------------------

def find_checklist_items(text):

    if not text:
        return []

    lines = [
        line.strip()
        for line in text.splitlines()
        if line.strip()
    ]

    tasks = []

    checklist_started = False

    checklist_labels = [
        "checklist",
        "preparation",
        "things to bring",
        "requirements",
        "before the event",
    ]

    for line in lines:

        lower_line = line.lower()

        if any(
            label in lower_line
            for label in checklist_labels
        ):

            checklist_started = True

            continue

        if checklist_started:

            if (
                lower_line.startswith("venue")
                or lower_line.startswith("contact")
                or lower_line.startswith("date")
                or lower_line.startswith("time")
            ):

                checklist_started = False

                continue

            # Remove bullets and numbering
            task = re.sub(
                r"^[\-\*\•\●\▪\d.)]+\s*",
                "",
                line,
            ).strip()

            if len(task) >= 3:

                tasks.append(
                    task[:200]
                )

    # Remove duplicate tasks
    unique_tasks = []

    for task in tasks:

        if task.lower() not in [
            existing.lower()
            for existing in unique_tasks
        ]:

            unique_tasks.append(task)

    return unique_tasks
