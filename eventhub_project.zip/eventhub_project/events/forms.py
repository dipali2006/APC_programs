
import os

from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm

from .models import Event


class EventForm(forms.ModelForm):

    upload = forms.FileField(
        required=False,
        label="Upload Event Poster (Image or PDF)",
        help_text="Supported formats: JPG, JPEG, PNG, BMP, PDF",
    )

    class Meta:
        model = Event

        fields = [
            "title",
            "event_type",
            "date",
            "time",
            "venue",
            "description",
            "upload",
        ]

        widgets = {
            "title": forms.TextInput(
                attrs={
                    "placeholder": "Enter event name",
                }
            ),

            "event_type": forms.TextInput(
                attrs={
                    "placeholder": "Example: Wedding, Birthday, Workshop",
                }
            ),

            "date": forms.DateInput(
                attrs={
                    "type": "date",
                }
            ),

            "time": forms.TimeInput(
                attrs={
                    "type": "time",
                }
            ),

            "venue": forms.TextInput(
                attrs={
                    "placeholder": "Enter event venue",
                }
            ),

            "description": forms.Textarea(
                attrs={
                    "rows": 4,
                    "placeholder": "Enter your event description...",
                }
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Allow OCR to fill these fields when they are empty.
        self.fields["title"].required = False
        self.fields["date"].required = False

        self.fields["description"].required = False
        self.fields["time"].required = False
        self.fields["venue"].required = False
        self.fields["event_type"].required = False

    def clean_upload(self):
        uploaded_file = self.cleaned_data.get("upload")

        if uploaded_file:

            allowed_extensions = [
                ".jpg",
                ".jpeg",
                ".png",
                ".bmp",
                ".pdf",
            ]

            extension = os.path.splitext(
                uploaded_file.name
            )[1].lower()

            if extension not in allowed_extensions:
                raise forms.ValidationError(
                    "Upload a JPG, JPEG, PNG, BMP, or PDF file."
                )

            if uploaded_file.size > 10 * 1024 * 1024:
                raise forms.ValidationError(
                    "File size must be less than 10 MB."
                )

        return uploaded_file


class SignUpForm(UserCreationForm):

    email = forms.EmailField(
        required=True,
        label="Email",
    )

    class Meta:
        model = User

        fields = [
            "email",
            "password1",
            "password2",
        ]

    def clean_email(self):
        email = self.cleaned_data["email"].lower().strip()

        if User.objects.filter(username=email).exists():
            raise forms.ValidationError(
                "This email is already registered. "
                "Please login or use another email."
            )

        if User.objects.filter(email=email).exists():
            raise forms.ValidationError(
                "This email is already registered. "
                "Please login or use another email."
            )

        return email

    def save(self, commit=True):
        user = super().save(commit=False)

        email = self.cleaned_data["email"]

        user.username = email
        user.email = email

        if commit:
            user.save()

        return user
